<?php include 'header.php'; ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Hoşgeldin <?php echo $admin['admin_ad']." ".$admin['admin_soyad'] ?></h1>
                        
                    </div>
                    <p>İşlemleri Sol Taraftaki Menüden Seçebilirsin. Admin Profilini Görüntülemek İçin Sağ Üstteki Alana Tıklayınız.</p>

                
                    
                  </div>

                    <!-- Content Row -->
                

              
                <!-- /.container-fluid -->

           
            <!-- End of Main Content -->

           <?php include 'footer.php' ?>