<?php 

try {
	$db=new PDO("mysql:host=localhost;dbname=erdinco1_cvsite;charset=utf8",'erdinco1_erdincozturk','yalova771907');
	
} catch (PDOException $e) {
	echo $e -> getMessage();
}


 ?>