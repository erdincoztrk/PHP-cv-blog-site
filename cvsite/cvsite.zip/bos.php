








<?php 

$kullanici = $db->prepare("SELECT * FROM kullanici where kullanici_id = ?");
$kullanici->execute([1]);
$kullanicigetir = $kullanici->fetch(PDO::FETCH_ASSOC);
$adsoyad = explode(" ", $kullanicigetir['kullanici_author']);

echo "Kişisel Web Siteme Hoşgeldiniz! Ben".$adsoyad[0].$adsoyad[1]."! İyi Gezinmeler Dilerim :)";

 ?>